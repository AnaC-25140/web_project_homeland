# Tripleten web_project_homeland
El objetivo de este proyecto es practicar grid y el diseño responsivo usando queries

https://github.com/AnaC-25140/web_project_homeland
